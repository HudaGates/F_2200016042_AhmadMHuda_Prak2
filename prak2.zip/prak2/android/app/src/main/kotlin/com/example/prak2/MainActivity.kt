package com.example.prak2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
